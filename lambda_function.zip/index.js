exports.handler = async (event, context) => {
  const response = {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ message: "Script Actualizado desde el pipeline" }),
  };

  return response;
};